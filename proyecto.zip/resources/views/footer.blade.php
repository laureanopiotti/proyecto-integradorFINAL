<head>
        <link rel="stylesheet" href="css/footer.css">
    </head>
    <!-- footer-->
    <footer class="main-footer">
        <nav>
            <article class="column-1 footer-article">
                <h3>Empresa</h3>
                <a href="#" class="link">Sobre nosotros</a>
                <a href="#" class="link">Envíos</a>
                <a href="#" class="link">Cambios</a> 
            </article>
    
            <article class="column-2 footer-article">
                <h3>Ayuda</h3>
                <a href="#" class="link">Contacto</a>
                <a href="mailto:alanmbenitez@hotmail.com"?subjet="Mensaje desde el sitio web" class="contact-logo"><i class="fas fa-envelope-square i"></i></a>
            </article>
    
            <article class="column-3 footer-article">
                <h3>Encontranos</h3>
                <div class="social-network">
                    <a href="http://facebook.com" target="_blank"><i class="fab fa-facebook"></i></a>
                    <a href="http://Twitter.com" target="_blank"><i class="fab fa-twitter-square"></i></a>
                    <a href="http://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                </div>
            </article>
    
            <article class="column-4 footer-article">
                <h3>Noticias</h3>
                <a href="#" class="link">Boletín</a>
            </article>
        </nav>
    
        <section class="backtop">
            <a href="#main-header"><i class="fas fa-angle-double-up"></i></a>
        </section>
    
    </footer>
    
    