<?php $__env->startSection('assets'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
<?php $__env->stopSection(); ?>
	
<?php $__env->startSection('content'); ?>
<div id='login-container' class="container-fluid p-0 d-flex flex-column">
	<div class="title text-center p-3">
		<h1>Accede a tu cuenta</h1>	
	</div>
	<form class='container  p-3  mb-3' action="<?php echo e(route("login")); ?>" method="post">
	<?php echo csrf_field(); ?>
		<div class="form-group>
			<label for="userEmail">Email</label>
			<input type="text" name='email' id="userEmail" class="form-control mx-sm-3 col-12 col-lg-6" value="<?php echo e(old('email')); ?>" autofocus>
			<strong><?php echo e($errors->first('email')); ?></strong>

		</div>
		<div class="form-group">
			<label for="inputPassword6">Contraseña</label>
			<input type="password" name='password' id="inputPassword6" class="form-control mx-sm-3 col-12 col-lg-6" value="<?php echo e(old('password')); ?>" autofocus>
			<strong><?php echo e($errors->first('password')); ?></strong>

		</div>
		<div class="form-check mb-3">
			<input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

			<label class="form-check-label" for="remember">
				<?php echo e(__('Recordarme')); ?>

			</label>
		</div>

		<div class='p-0 ml-2 col-12 col-lg-6'>
			<button class="btn btn-md btn-dark btn-block" type="submit">Entrar</button>
			<a class="btn btn-link text-dark text-center btn-block" href="<?php echo e(route('password.request')); ?>">
				<?php echo e(__('Olvidaste la contraseña?')); ?>

			</a>
		</div>
		
	</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>