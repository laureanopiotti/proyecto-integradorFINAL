<?php $__env->startSection('assets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/products.css')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <style>
        .pagination a {color:black}
        .product-grid{padding:0 0 0px !important;}
        .edit, .edit:hover{color:blue}
        .delete, .delete:hover{color:red}

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id='product-container' class="container-fluid p-0">
    <div class="container pt-3 pb-3">
        <form class='form-group' method="POST" action="<?php echo e(route('product.store')); ?>" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="product-grid mb-4 mt-4">
                        <div class="product-image">
                            <img class="pic-1" src="<?php echo e(asset('storage/products/default.png')); ?>">
                            <img class="pic-2" src="<?php echo e(asset('storage/products/default2.png')); ?>">  
                        </div>
                    </div>
                    <div class='container-fluid p-0 mb-4'>
                        <label for="imageLoc">Imagen 1</label>
                        <input type="file" value="imageLoc" class='form-control-file' name="imageLoc" id="imageLoc">
                        <hr>
                        <label for="imageLoc2">Imagen 2</label>
                        <input type="file" value="imageLoc2" class='form-control-file' name="imageLoc2" id="imageLoc2">
                    </div>
                </div> 
                <div class="col-md-9 col-sm-6">
                    <article class="card-body p-2 pl-4">
                        <dt>Nombre</dt>
                        <h3 class="title mb-3"><input type="text" style="width: 100%;" name="name" id="name" value=""></h3>
                        <hr>
                        <dl class="item-property">
                            <dt>Descripción</dt>
                            <dd><input type="text" class='form-control' name="description" id="description" value=""></dd>
                        </dl>
                        <dl class="param param-feature">
                            <dt>Género</dt>
                            <dd>
                                <select name="genre_id" id="genre_id">
                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </dd>
                        <dl class="param param-feature">
                            <dt>Categoría</dt>
                            <dd>
                                <select name="category_id" id="category_id">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </dd>
                        </dl>  <!-- item-property-hor .// -->
                        <dl class="param param-feature">
                            <dt>Talle</dt>
                            <dd>
                                <select name="size_id" id="size_id">
                                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($size->id); ?>"><?php echo e($size->size); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </dd>
                        </dl>  <!-- item-property-hor -->
                        <dl class="param param-feature">
                            <dt>Precio $</dt>
                            <dd><input type="number" class='form-control' name="price" id="price" value=""></dd>
                        </dl>  <!-- item-property-hor .// -->
                        <dl class="param param-feature">
                            <dt>Cantidad</dt>
                            <dd><input type="number" class='form-control' name="stock" id="price" value=""></dd>
                        </dl>  <!-- item-property-hor .// -->
                        <hr>
                        <div class='container-fluid p-0'>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-info btn-md">Volver</a>
                            <input type="submit" class="btn btn-primary btn-md" value="Crear">
                        </div>
                    </article> 
                </div> 
                
            </div>
        </form>
        <?php if($errors->any()): ?>
        <div class="container alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    </div>
</div>   
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>