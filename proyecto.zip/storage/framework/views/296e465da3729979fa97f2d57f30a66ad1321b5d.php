<?php $__env->startSection('assets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/products.css')); ?>">
    <style>
        .pagination a {color:black}
        #product-container {background-image: url('../images/not-found/not-found1.jpg');}
        .no-results {text-shadow: 2px 2px #000}
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id='product-container' class="container-fluid p-0">
<div class="container pt-3 pb-3">
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid mb-4">
                <div class="product-image">
                    <img class="pic-1" src="<?php echo e($product->imageLoc); ?>">
                    <img class="pic-2" src="<?php echo e($product->imageLoc2); ?>">
                    <ul class="social">
                        <li><a href="<?php echo e(route('front.product.show',$product->id)); ?>" data-tip="Quick View"><i class="fa fa-search"></i></a></li>
                    <li><a href="<?php echo e(route('cart.add',$product->id)); ?>" data-tip="Add to Cart"><i class="fa fa-shopping-cart"></i></a></li>
                    </ul>   
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#"><?php echo e($product->name); ?></a></h3>
                    <h4 class="genre"><?php echo e($product->genre['name']); ?></h4>
                    <p class="price">$ <?php echo e($product->price); ?></p>
                </div>
            </div>
        </div>      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div style='height:400px' class='no-results-container d-flex container-fluid mb-5 text-white text-center'>
            <h2 class='no-results align-self-center'>No se encontraron resultados.</h2>
        </div>
            
        <?php endif; ?>
        </div>
    <div class='container-fluid d-flex justify-content-center'>
        <?php echo e($products->links()); ?>

    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>