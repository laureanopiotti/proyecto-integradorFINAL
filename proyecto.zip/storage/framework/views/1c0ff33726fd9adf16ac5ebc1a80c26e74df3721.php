
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=1.0">
		<title>PIERRE OUTFIT</title>
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="css/main.css">
		<link rel="stylesheet" href="css/profile.css">
		<link rel="stylesheet" href="css/footer.css">
		<link rel="stylesheet" href="css/header.css">
		<link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
	</head>

	<body>
        <?php echo e(dd(session()->get('auth'))); ?>

	<div class="main-container">

		<!-- config -->

		<!-- header -->
        
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<!-- banner -->
		<section class="main-banner" >
			<img src="images/banners/main-banner.jpg" alt="main-banner">
		</section>

		<!-- productos -->
            <!-- man-section -->
            

            <section class="container">

                    <article id="hombre" class="title">
                        <h2>Hombres</h2>
                    </article>
            
                    <section class="buzos">
            
                        <article class="cloth-type-title">
                    
                            <h3>Buzos</h3>

                        </article>
            
            
                        <section class="products-container">
                                
            
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                <?php if($product['category_id'] == 1 && $product['genre'] == "Men"): ?>
                                    <article class='product'>
                                        <a href="view/product.view.php?product=<?=$product->id?>">
                                            <img class="image" src="<?php echo e($product->imageLoc); ?> width=100%">
                                        </a>	
                                        <h2><?php echo e($product->name); ?></h2>
                                        <h2>Talles</h2>
                                        <h3><?php echo e($product->name); ?></h3>
                                        <a href="<?php echo e(route('product')); ?>?product=<?php echo e($product->id); ?>"><i class="fas fa-plus-square"></i> Agregar al carrito</a>
            
                                    </article>
            
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
                        </section>
            
                    </section>
            
            
                    <section class="remeras">
            
                        <article class="cloth-type-title">
                            <h3>Remeras</h3>
                        </article>
                
                
                        <section class="products-container">
                                    
                
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                <?php if($product['category_id'] == 2 && $product['genre'] == "Men"): ?>
            
                                    <article class='product'>
                                        <a href="view/product.view.php?product=<?=$product->id?>">
                                            <img class="image" src="<?php echo e($product->imageLoc); ?> width=100%">
                                        </a>	
                                        <h2><?php echo e($product->name); ?></h2>
                                        <h2>Talles</h2>
                                        <h3><?php echo e($product->name); ?></h3>
                                        <a href="<?php echo e(route('product')); ?>?product=<?php echo e($product->id); ?>"><i class="fas fa-plus-square"></i> Agregar al carrito</a>
                                    </article>
            
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </section>
                    </section>
            
            
                    <section class="jeans">
            
                        <article class="cloth-type-title">
                            <h3>Jeans</h3>
                        </article>
            
            
                        <section class="products-container">
                                
            
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                <?php if($product['category_id'] == 3 && $product['genre'] == "Men"): ?>
            
                                    <article class='product'>
                                        <a href="view/product.view.php?product=<?=$product->id?>">
                                            <img class="image" src="<?php echo e($product->imageLoc); ?> width=100%">
                                        </a>	
                                        <h2><?php echo e($product->name); ?></h2>
                                        <h2>Talles</h2>
                                        <h3><?php echo e($product->name); ?></h3>
                                        <a href="<?php echo e(route('product')); ?>?product=<?php echo e($product->id); ?>"><i class="fas fa-plus-square"></i> Agregar al carrito</a>
                                    </article>
            
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
            
                        </section>
            
                    </section>        
		<!-- men banner -->
		<section class="main-banner">
			<img src="images/banners/men-banner.jpg" alt="men-banner">
		</section>

		<!-- productos -->
			<!-- woman-section -->
            <section class="container">

                <article id="mujer" class="title">
                    <h2>Mujeres</h2>
                </article>
                    
                
                <section class="buzos">
                
                    <article class="cloth-type-title">
                        <h3>Buzos</h3>
                    </article>
            
                    <section class="products-container">
                            
        
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                            <?php if($product['category_id'] == 1 && $product['genre'] == "Women"): ?>
    
                                <article class='product'>
                                    <a href="view/product.view.php?product=<?=$product->id?>">
                                        <img class="image" src="<?php echo e($product->imageLoc); ?> width=100%">
                                    </a>	
                                    <h2><?php echo e($product->name); ?></h2>
                                    <h2>Talles</h2>
                                    <h3><?php echo e($product->name); ?></h3>
                                    <a href="<?php echo e(route('product')); ?>?product=<?php echo e($product->id); ?>"><i class="fas fa-plus-square"></i> Agregar al carrito</a>
                                </article>
    
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
        
                    </section>
        
                </section>
        
                <section class="remeras">
                
                    <article class="cloth-type-title">
                        <h3>Remeras</h3>
                    </article>
            
                    <section class="products-container">
                            
        
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                            <?php if($product['category_id'] == 2 && $product['genre'] == "Women"): ?>
    
                                <article class='product'>
                                    <a href="view/product.view.php?product=<?=$product->id?>">
                                        <img class="image" src="<?php echo e($product->imageLoc); ?> width=100%">
                                    </a>	
                                    <h2><?php echo e($product->name); ?></h2>
                                    <h2>Talles</h2>
                                    <h3><?php echo e($product->name); ?></h3>
                                    <a href="<?php echo e(route('product')); ?>?product=<?php echo e($product->id); ?>"><i class="fas fa-plus-square"></i> Agregar al carrito</a>
                                </article>
    
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
        
                    </section>
        
                </section>
        
            
                <section class="jeans">
                
                    <article class="cloth-type-title">
                        <h3>Jeans</h3>
                    </article>
            
                    <section class="products-container">
                            
        
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                            <?php if($product['category_id'] == 3 && $product['genre'] == "Women"): ?>
    
                                <article class='product'>
                                    <a href="view/product.view.php?product=<?=$product->id?>">
                                        <img class="image" src="<?php echo e($product->imageLoc); ?> width=100%">
                                    </a>	
                                    <h2><?php echo e($product->name); ?></h2>
                                    <h2>Talles</h2>
                                    <h3><?php echo e($product->name); ?></h3>
                                    <a href="<?php echo e(route('product')); ?>?product=<?php echo e($product->id); ?>"><i class="fas fa-plus-square"></i> Agregar al carrito</a>
                                </article>
    
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
        
                    </section>
        
                </section>
        
            </section> 
                
		<!-- women banner -->
		<section class="main-banner">
			<img src="images/banners/women-banner.jpg" alt="women-banner">
		</section>

		<!-- productos -->
			<!-- kids-section -->
            <section class="container">

                <article id="ninio" class="title">
                    <h2>Niños</h2>
                </article>
        
            <!-- cloth-type-section -->
                <section class="buzos">
                
                    <article class="cloth-type-title">
                        <h3>Buzos</h3>
                    </article>
        
                    <section class="products-container">
                            
        
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                            <?php if($product['category_id'] == 1 && $product['genre'] == "Kids"): ?>
    
                                <article class='product'>
                                    <a href="view/product.view.php?product=<?=$product->id?>">
                                        <img class="image" src="<?php echo e($product->imageLoc); ?> width=100%">
                                    </a>	
                                    <h2><?php echo e($product->name); ?></h2>
                                    <h2>Talles</h2>
                                    <h3><?php echo e($product->name); ?></h3>
                                    <a href="<?php echo e(route('product')); ?>?product=<?php echo e($product->id); ?>"><i class="fas fa-plus-square"></i> Agregar al carrito</a>
                                </article>
    
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
        
                    </section>
        
                </section>
        
        
                <section class="remeras">
                    
                    <article class="cloth-type-title">
                        <h3>Remeras</h3>
                    </article>
        
                    <section class="products-container">
                            
        
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                            <?php if($product['category_id'] == 2 && $product['genre'] == "Kids"): ?>
    
                                <article class='product'>
                                    <a href="view/product.view.php?product=<?=$product->id?>">
                                        <img class="image" src="<?php echo e($product->imageLoc); ?> width=100%">
                                    </a>	
                                    <h2><?php echo e($product->name); ?></h2>
                                    <h2>Talles</h2>
                                    <h3><?php echo e($product->name); ?></h3>
                                    <a href="<?php echo e(route('product')); ?>?product=<?php echo e($product->id); ?>"><i class="fas fa-plus-square"></i> Agregar al carrito</a>
                                </article>
    
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
        
                    </section>
        
                </section>
        
        
        
                <section class="jeans">
                    
                    <article class="cloth-type-title">
                        <h3>Jeans</h3>
                    </article>
        
                    <section class="products-container">
                            
        
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                            <?php if($product['category_id'] == 3 && $product['genre'] == "Kids"): ?>
    
                                <article class='product'>
                                    <a href="view/product.view.php?product=<?=$product->id?>">
                                        <img class="image" src="<?php echo e($product->imageLoc); ?> width=100%">
                                    </a>	
                                    <h2><?php echo e($product->name); ?></h2>
                                    <h2>Talles</h2>
                                    <h3><?php echo e($product->name); ?></h3>
                                    <a href="<?php echo e(route('product')); ?>?product=<?php echo e($product->id); ?>"><i class="fas fa-plus-square"></i> Agregar al carrito</a>
                                </article>
    
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
        
                    </section>
        
                </section>
        
        
            </section>
            

		<!-- kids banner -->
		<section class="main-banner">
			<img src="images/banners/kids-banner.jpg" alt="kids-banner">
		</section>
		
	</div>

    <?php echo $__env->make("footer", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

	</body>
</html>
