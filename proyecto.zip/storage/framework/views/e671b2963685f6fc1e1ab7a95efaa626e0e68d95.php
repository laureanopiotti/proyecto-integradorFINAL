<?php $__env->startSection('assets'); ?>
	
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="<?php echo e(asset('css/indexadminproducts.css')); ?>">
<script src="<?php echo e(asset('js/indexadminproducts.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
	<div class="table-wrapper m-0">
		<div class="table-title">
			<div class="row">
				<div class="col-sm-6">
					<h2>Administración de <strong>Productos</strong></h2>
				</div>
				<div class="col-sm-6">						
					<a href="<?php echo e(route('product.create')); ?>" class="btn btn-success"><i class="material-icons">&#xE147;</i> <span>Agregar</span></a>
				</div>
			</div>
		</div>
		<table id='table' class="table table-striped table-hover  w-100">
			<thead class='w-100'>
				<tr>
					<th>Nombre</th>
					<th>Género</th>
					<th>Categoría</th>
					<th>Precio</th>
					<th>Tamaño</th>
					<th>Cantidad</th>
					<th>Fecha Modificación</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody class='w-100'>
				<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				<tr>
					<td><a href="<?php echo e(route('product.show',['id' => $product->id])); ?>"><?php echo e($product->name); ?></a></td>
					<td><?php echo e($product->genre['name']); ?></td>
					<td><?php echo e($product->category['name']); ?></td>
					<td>$ <?php echo e($product->price); ?></td>
					<td><?php echo e($product->size['size']); ?></td>
					<td><?php echo e($product->stock); ?></td>
					<td><?php echo e($product->updated_at); ?></td>
					<td class=d-flex>
						<a href="<?php echo e(route('product.edit', ['id' => $product->id])); ?>" class="edit"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>
						<form id='<?php echo e($product->id); ?>' class='form-delete' action="<?php echo e(route('product.destroy',['id' => $product->id])); ?>" method="post">
							<?php echo method_field('DELETE'); ?>
							<?php echo csrf_field(); ?>
							<a id='delete-link-<?php echo e($product->id); ?>' href="#" class="delete"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>