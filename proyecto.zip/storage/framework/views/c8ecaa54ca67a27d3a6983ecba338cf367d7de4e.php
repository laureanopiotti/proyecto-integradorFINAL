<?php $__env->startSection('assets'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id='register-container' class="container-fluid p-0">
    <div class="formu1">
    <form name="formulario" action="<?php echo e(route('register')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

		<h2>Registrate</h2>
		<p class="hint-text">Crea tu cuenta. Y comenza a comprar.</p>
		<div class="form-group" >
            <input id='name' type="text" class="form-control" name="name" placeholder="Nombre" value="<?php echo e(old('name')); ?>" >

            <?php if($errors->has('name')): ?>
                <strong><?php echo e($errors->first('name')); ?></strong>

        <?php endif; ?>
        <p id="errorName"></p>

        </div>
		<div class="form-group" >
            <input id='lname' type="text" class="form-control" name="lname" placeholder="Apellido" value="<?php echo e(old('lname')); ?>">
            <?php if($errors->has('lname')): ?>
                <strong><?php echo e($errors->first('lname')); ?></strong>
        <?php endif; ?>
        <p id="errorlName"></p>
        </div>

        <div class="form-group">
        	<input id='email' type="text" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" >
            <?php if($errors->has('email')): ?>
                <strong><?php echo e($errors->first('email')); ?></strong>
        <?php endif; ?>
        <p id="errorEmail"></p>
        </div>
		<div class="form-group">
            <input id='password' type="password" class="form-control" name="password" placeholder="Contraseña" ><small id="passwordHelpInline" class="text-muted">
                      Debe ser mayor a 8 digitos alfanumericos y tener al menos una mayuscula y una minuscula
              </small>
            <?php if($errors->has('password')): ?>
                <strong><?php echo e($errors->first('password')); ?></strong>
            <?php endif; ?>
            <p id="errorPass"></p>
        </div>
		<div class="form-group">
                <input id="password-confirm" type="password" class="form-control" placeholder="Confirmar Contrasena" name="password_confirmation" >
                <p id="errorPass2"></p>
            </div>
        <div class="form-group mx-auto">
            <h6 class="text-center">Ingresa tu genero</h6>
            <ul class="list-inline text-center">
                <li class="list-inline-item"><input  id ="male" type="radio" name="genre" value="male" > Hombre</li>
                <li class="list-inline-item"><input id ="female" type="radio" name="genre" value="female" > Mujer </li>
                <li class="list-inline-item"> <input id ="other" type="radio" name="genre" value="other" > Otro</li>
                <p id= "errorGenres"></p>
            </ul>
            </div>


        <div class="form-group">
            <h6 style="text-align: center">Ingresa tu nuevo avatar!</h6>
            <input id="avatar" type="file" class="form-control" name="avatar" placeholder="Ingresa tu nuevo avatar!">
            <?php if($errors->has('avatar')): ?>
                <strong><?php echo e($errors->first('avatar')); ?></strong>

        <?php endif; ?>
        <p id= "errorAvatar"></p>
        </div>
        <div class="form-group">
			<label class="checkbox-inline"><input id="confirm" type="checkbox" name="confirm" > Acepto los <a href="#">Terminos de Uso</a> y <a href="#">la Politica de privacidad </a></label>
            <p id= "errorConfirm"></p>

		</div>
		<div class="form-group">
            <button id="button" type="submit" class="btn btn-success btn-lg btn-block">
                <?php echo e(__('Registrate!')); ?>

            </button>
        </div>

        <div class="separador"><i>or</i></div>

      <div class="text-center social-btn">
            <a href="<?php echo e(url('/auth/facebook')); ?>" class="btn btn-primary btn-block"><i class="fab fa-facebook"></i>Inicia Sesión con <b>Facebook</b></a>
            <a href="#" class="btn btn-info btn-block"><i class="fab fa-twitter-square"></i>Inicia Sesión con <b>Twitter</b></a>

            <a href="<?php echo e(url('/auth/google')); ?>" class="btn btn-danger btn-block"><i class="fab fa-instagram"></i>Inicia Sesión con <b>Google</b></a>

        </div>




        <div class="text-center">Ya tenes una cuenta? <a class="text-dark" href="<?php echo e(route('login')); ?>">Ingresa</a></div>
    </form>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>