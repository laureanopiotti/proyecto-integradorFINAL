<?php $__env->startSection('assets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/men.css')); ?>">
    <style>
        .pagination a {color:black}
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3 mb-3">
    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
        <div class="col-md-3 col-sm-6">
            <div class="product-grid mb-4">
                <div class="product-image">
                    <img class="pic-1" src="<?php echo e($product->imageLoc); ?>">
                    <img class="pic-2" src="<?php echo e($product->imageLoc2); ?>">
                    <ul class="social">
                        <li><a href="" data-tip="Quick View"><i class="fa fa-search"></i></a></li>
                        <li><a href="" data-tip="Add to Cart"><i class="fa fa-shopping-cart"></i></a></li>
                    </ul>   
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#"><?php echo e($product->name); ?></a></h3>
                    <p class="price">$ <?php echo e($product->price); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
    </div>
    <div class='container-fluid d-flex justify-content-center'>
        <?php echo e($products->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>